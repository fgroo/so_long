/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nix <nix@student.42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/28 13:18:48 by nix               #+#    #+#             */
/*   Updated: 2025/02/28 21:34:56 by nix              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./minilibx-linux/mlx.h"
#include <stdlib.h>

typedef struct s_list
{
	void	*mlx_ptr;
	void	*win_ptr;
	void	*img;
	int		height;
	int		width;
} t_list;


void	Kill_Display(t_list *lst)
{
	mlx_destroy_display(lst->mlx_ptr);
	free(lst->mlx_ptr);
}

int	playermovement(int keysym, t_list *lst)
{
	if (keysym == 65307) // ESC Taste
	{
		mlx_destroy_window(lst->mlx_ptr, lst->win_ptr);
		exit(0);
	}
	if (keysym == 119) // W
		lst->height -= 50;
	if (keysym == 97)  // A
		lst->width -= 50;
	if (keysym == 115) // S
		lst->height += 50;
	if (keysym == 100) // D
		lst->width += 50;

	// Nach Tastendruck Szene neu zeichnen
	render_frame(data);
	return (0);
}
int	read_map()

ich habe die idee, dass ich die erste zeile checke, ob alles eine 1 (Wand) ist.
Währenddessen auch die len der ersten zeile gemerkt habe, weil die folgenden zeilen dürfen nicht mehr chars haben als die davor.
die nächsten zeilen werden auf erste und letzte zeile mit 1 geprüft. wenn eine zeile nur aus 1 besteht und keine newline danach kommt, dann ist das die letzte und wir freen und verlassen die funktion.

für die malloc sachen (ich habe gerade kopfschemrzen): erstmal immer buffersize 1 machen bis newline gefunden. dann buffersize ist len.

immer wenn eine 1 gelesen wird muss seperat gezählt werden, damit man gucken kann ob die letzte zeilt genauseo viele wände hat wie die erste.


int	main(void)
{
	t_list	lst;

	lst.width = 400;
	lst.height = 500;

	lst.mlx_ptr = mlx_init(lst.mlx_ptr);
	lst.win_ptr = mlx_new_window(lst.mlx_ptr, 400 ,500 ,"dick");
	
	lst.img = mlx_xpm_file_to_image(lst.mlx_ptr, "Walls.xpm", NULL, NULL);
	mlx_put_image_to_window(lst.mlx_ptr, lst.win_ptr, lst.img, 300, 200);
	mlx_key_hook(lst.win_ptr, playermovement, &lst);
	mlx_loop(lst.mlx_ptr);
	return (0);
}